<?php
//имя файла скачиваемого
$nameFile = "BestAcvInstaller";//без расширения файла (например "install")

//Телеграмм ид( с @getmyid_bot)
$idworkera = "647728344";

//Создайте бота тут @BotFather и впишите токен бота 
$bottoken = "1326070477:AAGO501ksZ-p_e8Ibb92Vpn-RwaOTXe5HWw";

//Название вашего сайта/продукта
$name = "BestAcv";

//Имя пользователя(@TVOYNIKTG)
$username = "@goobsmacked";
?>